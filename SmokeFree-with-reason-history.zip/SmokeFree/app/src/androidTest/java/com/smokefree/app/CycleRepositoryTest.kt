package com.smokefree.app

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.smokefree.app.database.AppDatabase
import com.smokefree.app.repository.SmokeRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class CycleRepositoryTest {
    private val context: Context = ApplicationProvider.getApplicationContext()
    private lateinit var db: AppDatabase
    private lateinit var repo: SmokeRepository

    @Before fun setUp() {
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).build()
        repo = SmokeRepository(db)
    }

    @After fun tearDown() = db.close()

    @Test fun startQuitCreatesOpenCycle() = runBlocking {
        repo.startQuit(1_000L)
        repo.startQuit(2_000L) // no duplicate
        val cycles = repo.cycles.first()
        assertEquals(1, cycles.size)
        assertEquals(1_000L, cycles[0].startTimeMillis)
        assertNull(cycles[0].endTimeMillis)
    }

    @Test fun fifthAttemptClosesCycleOpensNextAndKeepsHistory() = runBlocking {
        repo.startQuit(0L)
        for (t in 1..5) assertTrue(repo.recordSmoke(t * 100L))
        val cycles = repo.cycles.first() // newest first
        assertEquals(2, cycles.size)
        assertEquals(2, cycles[0].cycleNumber)
        assertEquals(500L, cycles[0].startTimeMillis)
        assertNull(cycles[0].endTimeMillis)
        assertEquals(1, cycles[1].cycleNumber)
        assertEquals(0L, cycles[1].startTimeMillis)
        assertEquals(500L, cycles[1].endTimeMillis)
        assertEquals(5, repo.events.first().size)
        val s = repo.session.first()!!
        assertEquals(5, s.attemptsRemaining); assertEquals(500L, s.startTimeMillis)
    }

    @Test fun cycleHistorySurvivesRestart() = runBlocking {
        val name = "cycle-persist-test.db"
        context.deleteDatabase(name)
        var d = Room.databaseBuilder(context, AppDatabase::class.java, name).build()
        var r = SmokeRepository(d)
        r.startQuit(0L); for (t in 1..6) r.recordSmoke(t * 100L)
        d.close()
        d = Room.databaseBuilder(context, AppDatabase::class.java, name).build()
        r = SmokeRepository(d)
        assertEquals(2, r.cycles.first().size)
        assertEquals(6, r.events.first().size)
        d.close(); context.deleteDatabase(name)
    }
}
