package com.smokefree.app

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.smokefree.app.database.AppDatabase
import com.smokefree.app.database.Migrations
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MigrationTest {
    private val context: Context = ApplicationProvider.getApplicationContext()
    private val name = "migration-test.db"

    @Before fun setUp() { context.deleteDatabase(name) }
    @After fun tearDown() { context.deleteDatabase(name) }

    @Test fun migrate1to2KeepsDataAndBackfillsCycles() = runBlocking {
        // Build a genuine version-1 database by hand.
        val old = context.openOrCreateDatabase(name, Context.MODE_PRIVATE, null)
        old.execSQL("CREATE TABLE IF NOT EXISTS `session` (`id` INTEGER NOT NULL, `active` INTEGER NOT NULL, `startTimeMillis` INTEGER NOT NULL, `cycleNumber` INTEGER NOT NULL, `attemptsRemaining` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        old.execSQL("CREATE TABLE IF NOT EXISTS `smoke_events` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `timestampMillis` INTEGER NOT NULL, `cycleNumber` INTEGER NOT NULL, `attemptNumber` INTEGER NOT NULL)")
        for (i in 1..5) old.execSQL("INSERT INTO smoke_events (timestampMillis, cycleNumber, attemptNumber) VALUES (${i * 100}, 1, $i)")
        old.execSQL("INSERT INTO smoke_events (timestampMillis, cycleNumber, attemptNumber) VALUES (600, 2, 1)")
        old.execSQL("INSERT INTO smoke_events (timestampMillis, cycleNumber, attemptNumber) VALUES (700, 2, 2)")
        old.execSQL("INSERT INTO session (id, active, startTimeMillis, cycleNumber, attemptsRemaining) VALUES (1, 1, 500, 2, 3)")
        old.version = 1
        old.close()

        val db = Room.databaseBuilder(context, AppDatabase::class.java, name)
            .addMigrations(Migrations.MIGRATION_1_2)
            .build()
        val repo = com.smokefree.app.repository.SmokeRepository(db)

        assertEquals(7, repo.events.first().size)           // nothing lost
        assertEquals(3, repo.session.first()!!.attemptsRemaining)
        val cycles = repo.cycles.first()                     // newest first
        assertEquals(2, cycles.size)
        assertEquals(1, cycles[1].cycleNumber)
        assertEquals(100L, cycles[1].startTimeMillis)        // approximated: first event of cycle 1
        assertEquals(500L, cycles[1].endTimeMillis)
        assertEquals(2, cycles[0].cycleNumber)
        assertEquals(500L, cycles[0].startTimeMillis)        // exact saved start
        assertNull(cycles[0].endTimeMillis)
        db.close()
    }
}
