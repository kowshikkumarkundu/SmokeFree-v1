package com.smokefree.app

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.smokefree.app.database.AppDatabase
import com.smokefree.app.repository.SmokeRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SmokeRepositoryTest {
    private val context: Context = ApplicationProvider.getApplicationContext()
    private lateinit var db: AppDatabase
    private lateinit var repo: SmokeRepository

    @Before fun setUp() {
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).build()
        repo = SmokeRepository(db)
    }

    @After fun tearDown() = db.close()

    @Test fun startQuitStoresSession() = runBlocking {
        repo.startQuit(1_000L)
        val s = repo.session.first()!!
        assertTrue(s.active); assertEquals(1_000L, s.startTimeMillis); assertEquals(5, s.attemptsRemaining)
    }

    @Test fun fifthAttemptResetsAndKeepsHistory() = runBlocking {
        repo.startQuit(0L)
        repeat(5) { assertTrue(repo.recordSmoke(100L + it)) }
        val s = repo.session.first()!!
        assertEquals(5, s.attemptsRemaining)
        assertEquals(2, s.cycleNumber)
        assertEquals(104L, s.startTimeMillis)
        assertEquals(5, repo.events.first().size)
        repo.recordSmoke(500L)
        val events = repo.events.first()
        assertEquals(6, events.size)
        assertEquals(2, events.first().cycleNumber) // newest first
        assertEquals(1, events.first().attemptNumber)
    }

    @Test fun smokeWithoutSessionIsIgnored() = runBlocking {
        assertFalse(repo.recordSmoke(1L))
        assertTrue(repo.events.first().isEmpty())
    }

    @Test fun dataSurvivesRestart() = runBlocking {
        val name = "persist-test.db"
        context.deleteDatabase(name)
        var d = Room.databaseBuilder(context, AppDatabase::class.java, name).build()
        var r = SmokeRepository(d)
        r.startQuit(10L); r.recordSmoke(20L); r.recordSmoke(30L)
        d.close() // simulates the process being killed

        d = Room.databaseBuilder(context, AppDatabase::class.java, name).build()
        r = SmokeRepository(d)
        assertEquals(3, r.session.first()!!.attemptsRemaining)
        assertEquals(10L, r.session.first()!!.startTimeMillis)
        assertEquals(2, r.events.first().size)
        d.close()
        context.deleteDatabase(name)
    }
}
