package com.smokefree.app

import com.smokefree.app.model.QuitCycle
import com.smokefree.app.model.SessionState
import com.smokefree.app.model.SmokeEvent
import com.smokefree.app.utils.Formatters
import com.smokefree.app.utils.QuitLogic
import org.junit.Assert.*
import org.junit.Test

class CycleLogicTest {

    /** In-memory mirror of what SmokeRepository writes, built only from QuitLogic. */
    private class Ledger {
        var state: SessionState? = null
        val cycles = mutableListOf<QuitCycle>()
        val events = mutableListOf<SmokeEvent>()

        fun quit(now: Long) {
            val next = QuitLogic.startSession(state, now)
            if (next != state) {
                state = next
                cycles += QuitLogic.openCycle(next)
            }
        }

        fun smoke(now: Long) {
            val s = state
            val r = QuitLogic.recordSmoke(s, now) ?: return
            events += r.event
            if (r.cycleReset) {
                val i = cycles.indexOfFirst { it.cycleNumber == s!!.cycleNumber }
                cycles[i] = QuitLogic.closeCycle(cycles[i], now)
                cycles += QuitLogic.openCycle(r.newState)
            }
            state = r.newState
        }
    }

    @Test fun cycleCreation() {
        val l = Ledger()
        l.quit(1_000L)
        assertEquals(1, l.cycles.size)
        val c = l.cycles.single()
        assertEquals(1, c.cycleNumber)
        assertEquals(1_000L, c.startTimeMillis)
        assertNull(c.endTimeMillis)
        assertFalse(c.isCompleted)
        l.quit(9_999L) // pressing quit again must not create a second cycle
        assertEquals(1, l.cycles.size)
    }

    @Test fun cycleCompletion() {
        val open = QuitCycle(cycleNumber = 1, startTimeMillis = 1_000L)
        val closed = QuitLogic.closeCycle(open, 5_000L)
        assertEquals(5_000L, closed.endTimeMillis)
        assertTrue(closed.isCompleted)
        assertEquals(closed, QuitLogic.closeCycle(closed, 9_000L)) // already closed: unchanged
        assertEquals(1_000L, QuitLogic.closeCycle(open, 500L).endTimeMillis) // never before start
    }

    @Test fun cycleDuration() {
        val open = QuitCycle(cycleNumber = 1, startTimeMillis = 1_000L)
        assertEquals(4_000L, QuitLogic.cycleDurationMillis(open, 5_000L))
        val closed = QuitLogic.closeCycle(open, 3_000L)
        assertEquals(2_000L, QuitLogic.cycleDurationMillis(closed, 99_000L))
        assertEquals("1d 02h 03m 04s", Formatters.duration(((86_400L + 7_200L + 180L + 4L) * 1000L)))
    }

    @Test fun fifthAttemptClosesCycleAndStartsNext() {
        val l = Ledger()
        l.quit(0L)
        for (t in 1..5) l.smoke(t * 100L)
        assertEquals(5, l.events.size)
        assertEquals(2, l.cycles.size)
        val first = l.cycles[0]
        val second = l.cycles[1]
        assertEquals(500L, first.endTimeMillis)      // closed at the 5th event
        assertEquals(500L, second.startTimeMillis)   // new cycle starts at the same instant
        assertNull(second.endTimeMillis)
        assertEquals(2, l.state!!.cycleNumber)
        assertEquals(5, l.state!!.attemptsRemaining)
        assertEquals(500L, l.state!!.startTimeMillis) // timer reset
    }

    @Test fun fourAttemptsDoNotCloseCycle() {
        val l = Ledger()
        l.quit(0L)
        for (t in 1..4) l.smoke(t * 100L)
        assertEquals(1, l.cycles.size)
        assertNull(l.cycles[0].endTimeMillis)
        assertEquals(1, l.state!!.attemptsRemaining)
    }

    @Test fun historyPreservedAcrossResets() {
        val l = Ledger()
        l.quit(0L)
        for (t in 1..12) l.smoke(t * 100L)
        assertEquals(12, l.events.size)
        assertEquals(listOf(1, 2, 3), l.cycles.map { it.cycleNumber })
        assertEquals(500L, l.cycles[0].endTimeMillis)
        assertEquals(1_000L, l.cycles[1].endTimeMillis)
        assertNull(l.cycles[2].endTimeMillis)
        assertEquals(l.cycles[0].endTimeMillis, l.cycles[1].startTimeMillis) // contiguous
        assertEquals(l.cycles[1].endTimeMillis, l.cycles[2].startTimeMillis)
        // every cycle still has its own events with attempt numbers intact
        assertEquals(listOf(1, 2, 3, 4, 5), l.events.filter { it.cycleNumber == 1 }.map { it.attemptNumber })
        assertEquals(listOf(1, 2, 3, 4, 5), l.events.filter { it.cycleNumber == 2 }.map { it.attemptNumber })
        assertEquals(listOf(1, 2), l.events.filter { it.cycleNumber == 3 }.map { it.attemptNumber })
    }
}
