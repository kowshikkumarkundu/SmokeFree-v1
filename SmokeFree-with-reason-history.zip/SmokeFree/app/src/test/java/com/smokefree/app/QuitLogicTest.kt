package com.smokefree.app

import com.smokefree.app.model.SessionState
import com.smokefree.app.model.SmokeEvent
import com.smokefree.app.utils.ElapsedTime
import com.smokefree.app.utils.QuitLogic
import org.junit.Assert.*
import org.junit.Test

class QuitLogicTest {

    @Test fun startingQuitSession() {
        val s = QuitLogic.startSession(null, 1_000L)
        assertTrue(s.active)
        assertEquals(1_000L, s.startTimeMillis)
        assertEquals(5, s.attemptsRemaining)
        assertEquals(1, s.cycleNumber)
    }

    @Test fun startingWhileActiveChangesNothing() {
        val s = QuitLogic.startSession(null, 1_000L)
        assertEquals(s, QuitLogic.startSession(s, 9_999L))
    }

    @Test fun timerCalculation() {
        val ms = ((2 * 86_400L) + (3 * 3_600L) + (4 * 60L) + 5L) * 1000L + 999L
        val e = ElapsedTime.fromMillis(QuitLogic.elapsedMillis(0L, ms))
        assertEquals(ElapsedTime(2, 3, 4, 5), e)
        assertEquals(0L, QuitLogic.elapsedMillis(5_000L, 1_000L)) // clock moved back: never negative
    }

    @Test fun firstSmokingAttempt() {
        val s = QuitLogic.startSession(null, 0L)
        val r = QuitLogic.recordSmoke(s, 500L)!!
        assertEquals(4, r.newState.attemptsRemaining)
        assertEquals(1, r.event.attemptNumber)
        assertEquals(1, r.event.cycleNumber)
        assertEquals(500L, r.event.timestampMillis)
        assertFalse(r.cycleReset)
        assertEquals(0L, r.newState.startTimeMillis) // timer keeps running
    }

    @Test fun smokingWithoutActiveSessionDoesNothing() {
        assertNull(QuitLogic.recordSmoke(null, 1L))
    }

    @Test fun allFiveAttemptsDecrement() {
        var s = QuitLogic.startSession(null, 0L)
        val expected = listOf(4, 3, 2, 1)
        expected.forEachIndexed { i, remaining ->
            val r = QuitLogic.recordSmoke(s, 100L * (i + 1))!!
            assertEquals(remaining, r.newState.attemptsRemaining)
            assertEquals(i + 1, r.event.attemptNumber)
            assertFalse(r.cycleReset)
            s = r.newState
        }
    }

    @Test fun automaticResetAfterFifthAttempt() {
        var s = QuitLogic.startSession(null, 0L)
        repeat(4) { s = QuitLogic.recordSmoke(s, it.toLong() + 1)!!.newState }
        val fifth = QuitLogic.recordSmoke(s, 7_777L)!!
        assertEquals(5, fifth.event.attemptNumber)
        assertEquals(1, fifth.event.cycleNumber)
        assertTrue(fifth.cycleReset)
        assertTrue(fifth.newState.active)
        assertEquals(5, fifth.newState.attemptsRemaining)
        assertEquals(7_777L, fifth.newState.startTimeMillis)
        assertEquals(2, fifth.newState.cycleNumber)
    }

    @Test fun historyPreservedAndCyclesNumberedAcrossResets() {
        val history = mutableListOf<SmokeEvent>()
        var s: SessionState = QuitLogic.startSession(null, 0L)
        repeat(12) { i ->
            val r = QuitLogic.recordSmoke(s, i + 1L)!!
            history += r.event
            s = r.newState
        }
        assertEquals(12, history.size)
        assertEquals(List(5) { 1 } + List(5) { 2 } + List(2) { 3 }, history.map { it.cycleNumber })
        assertEquals(listOf(1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2), history.map { it.attemptNumber })
        assertEquals(3, s.cycleNumber)
        assertEquals(3, s.attemptsRemaining)
    }
}
