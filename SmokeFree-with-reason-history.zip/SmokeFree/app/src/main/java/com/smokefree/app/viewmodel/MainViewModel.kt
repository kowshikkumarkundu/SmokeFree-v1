package com.smokefree.app.viewmodel

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smokefree.app.data.UiState
import com.smokefree.app.database.AppDatabase
import com.smokefree.app.repository.SmokeRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repository = SmokeRepository(AppDatabase.getInstance(app))
    private var lastSmokeClick = 0L

    val uiState: StateFlow<UiState> =
        combine(repository.session, repository.events, repository.cycles) { session, events, cycles ->
            UiState(loaded = true, session = session, events = events, cycles = cycles)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState())

    /** Emits the current wall-clock time every second; only runs while the UI is visible. */
    val ticker: StateFlow<Long> = flow {
        while (true) {
            emit(System.currentTimeMillis())
            delay(1_000)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), System.currentTimeMillis())

    fun onQuit() {
        viewModelScope.launch { repository.startQuit() }
    }

    fun onSmoked(reason: String) {
        // Ignore accidental double-taps.
        val tick = SystemClock.elapsedRealtime()
        if (tick - lastSmokeClick < DEBOUNCE_MS) return
        lastSmokeClick = tick
        viewModelScope.launch { repository.recordSmoke(reason = reason.trim()) }
    }

    private companion object {
        const val DEBOUNCE_MS = 800L
    }
}
