package com.smokefree.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.smokefree.app.viewmodel.MainViewModel

@Composable
fun SmokeFreeApp(vm: MainViewModel = viewModel()) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val now by vm.ticker.collectAsStateWithLifecycle()
    var showHistory by rememberSaveable { mutableStateOf(false) }

    BackHandler(enabled = showHistory) { showHistory = false }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.fillMaxSize().safeDrawingPadding()) {
            if (showHistory) {
                HistoryScreen(state = state, now = now, onBack = { showHistory = false })
            } else {
                MainScreen(
                    state = state,
                    now = now,
                    onQuit = vm::onQuit,
                    onSmoked = vm::onSmoked,
                    onHistory = { showHistory = true }
                )
            }
        }
    }
}
