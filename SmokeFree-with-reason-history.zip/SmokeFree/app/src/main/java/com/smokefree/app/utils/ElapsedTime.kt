package com.smokefree.app.utils

data class ElapsedTime(val days: Long, val hours: Long, val minutes: Long, val seconds: Long) {
    companion object {
        fun fromMillis(millis: Long): ElapsedTime {
            val totalSeconds = (millis.coerceAtLeast(0L)) / 1000L
            return ElapsedTime(
                days = totalSeconds / 86_400L,
                hours = (totalSeconds % 86_400L) / 3_600L,
                minutes = (totalSeconds % 3_600L) / 60L,
                seconds = totalSeconds % 60L
            )
        }
    }
}
