package com.smokefree.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smokefree.app.data.UiState
import com.smokefree.app.utils.ElapsedTime
import com.smokefree.app.utils.QuitLogic

@Composable
fun MainScreen(
    state: UiState,
    now: Long,
    onQuit: () -> Unit,
    onSmoked: (String) -> Unit,
    onHistory: () -> Unit
) {
    val session = state.session
    var showReasonDialog by rememberSaveable { mutableStateOf(false) }
    var reason by rememberSaveable { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Smoke Free", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(32.dp))

        if (state.loaded) {
            if (session == null || !session.active) {
                Text("Ready when you are.", style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = onQuit,
                    modifier = Modifier.fillMaxWidth().height(64.dp)
                ) {
                    Text("I Quit Smoking", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                }
            } else {
                val elapsed = ElapsedTime.fromMillis(QuitLogic.elapsedMillis(session.startTimeMillis, now))
                Text("Smoke-free for", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TimeUnitBox(elapsed.days.toString(), "Days")
                    TimeUnitBox("%02d".format(elapsed.hours), "Hours")
                    TimeUnitBox("%02d".format(elapsed.minutes), "Min")
                    TimeUnitBox("%02d".format(elapsed.seconds), "Sec")
                }
                Spacer(Modifier.height(40.dp))
                Text("Remaining attempts", style = MaterialTheme.typography.labelLarge)
                Text(
                    session.attemptsRemaining.toString(),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    repeat(QuitLogic.MAX_ATTEMPTS) { index ->
                        val filled = index < session.attemptsRemaining
                        Spacer(
                            Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    if (filled) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Cycle ${session.cycleNumber}", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(32.dp))
                Button(
                    onClick = { reason = ""; showReasonDialog = true },
                    modifier = Modifier.fillMaxWidth().height(64.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SmokeRed, contentColor = Color.White)
                ) {
                    Text("I Smoked", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        TextButton(onClick = onHistory) { Text("History") }
    }

    if (showReasonDialog) {
        AlertDialog(
            onDismissRequest = { showReasonDialog = false },
            title = { Text("Why did it happen?") },
            text = {
                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Reason") },
                    placeholder = { Text("Write your reason...") },
                    minLines = 3,
                    maxLines = 5
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onSmoked(reason.trim())
                        showReasonDialog = false
                        reason = ""
                    },
                    enabled = reason.isNotBlank()
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showReasonDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun RowScope.TimeUnitBox(value: String, label: String) {
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            value,
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            maxLines = 1,
            softWrap = false
        )
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}
