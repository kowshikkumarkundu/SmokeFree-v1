package com.smokefree.app.data

import com.smokefree.app.model.QuitCycle
import com.smokefree.app.model.SessionState
import com.smokefree.app.model.SmokeEvent

data class UiState(
    val loaded: Boolean = false,
    val session: SessionState? = null,
    val events: List<SmokeEvent> = emptyList(),
    val cycles: List<QuitCycle> = emptyList()
)
