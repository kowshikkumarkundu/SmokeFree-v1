package com.smokefree.app.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.smokefree.app.model.SessionState
import kotlinx.coroutines.flow.Flow

@Dao
interface SessionDao {
    @Query("SELECT * FROM session WHERE id = 1")
    fun observe(): Flow<SessionState?>

    @Query("SELECT * FROM session WHERE id = 1")
    suspend fun get(): SessionState?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(state: SessionState)
}
