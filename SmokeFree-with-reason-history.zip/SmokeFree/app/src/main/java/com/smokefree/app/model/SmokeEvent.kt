package com.smokefree.app.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "smoke_events")
data class SmokeEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Exact moment of the event (epoch millis); date and time are derived from it. */
    val timestampMillis: Long,
    val cycleNumber: Int,
    val attemptNumber: Int,
    /** User-entered note explaining the event. */
    val reason: String = ""
)
