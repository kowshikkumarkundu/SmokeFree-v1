package com.smokefree.app.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.smokefree.app.model.QuitCycle
import kotlinx.coroutines.flow.Flow

@Dao
interface QuitCycleDao {
    /** Insert-or-update (a row carrying its existing id replaces itself). */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(cycle: QuitCycle): Long

    @Query("SELECT * FROM quit_cycle_history WHERE cycleNumber = :cycleNumber")
    suspend fun getByNumber(cycleNumber: Int): QuitCycle?

    @Query("SELECT * FROM quit_cycle_history ORDER BY cycleNumber DESC")
    fun observeAll(): Flow<List<QuitCycle>>
}
