package com.smokefree.app.utils

import com.smokefree.app.model.QuitCycle
import com.smokefree.app.model.SessionState
import com.smokefree.app.model.SmokeEvent

/** Pure business rules. No Android or database dependencies, so it is easy to unit test. */
object QuitLogic {
    const val MAX_ATTEMPTS = 5

    data class SmokeResult(
        val event: SmokeEvent,
        val newState: SessionState,
        /** True when this was the 5th attempt: the old cycle closes and a new one opens. */
        val cycleReset: Boolean
    )

    /** Starts a quit session. If one is already active it is returned unchanged. */
    fun startSession(previous: SessionState?, now: Long): SessionState {
        if (previous != null && previous.active) return previous
        return SessionState(
            active = true,
            startTimeMillis = now,
            cycleNumber = (previous?.cycleNumber ?: 0) + 1,
            attemptsRemaining = MAX_ATTEMPTS
        )
    }

    /** Applies one "I Smoked" press. Returns null when there is no active session. */
    fun recordSmoke(state: SessionState?, now: Long, reason: String = ""): SmokeResult? {
        if (state == null || !state.active) return null
        val attemptNumber = MAX_ATTEMPTS - state.attemptsRemaining + 1
        val event = SmokeEvent(
            timestampMillis = now,
            cycleNumber = state.cycleNumber,
            attemptNumber = attemptNumber,
            reason = reason
        )
        val remaining = state.attemptsRemaining - 1
        return if (remaining <= 0) {
            SmokeResult(
                event,
                SessionState(
                    active = true,
                    startTimeMillis = now,
                    cycleNumber = state.cycleNumber + 1,
                    attemptsRemaining = MAX_ATTEMPTS
                ),
                cycleReset = true
            )
        } else {
            SmokeResult(event, state.copy(attemptsRemaining = remaining), cycleReset = false)
        }
    }

    /** Creates the (open) history record for the cycle described by [state]. */
    fun openCycle(state: SessionState): QuitCycle =
        QuitCycle(cycleNumber = state.cycleNumber, startTimeMillis = state.startTimeMillis)

    /** Completes a cycle. Already-completed cycles are returned unchanged; end is never before start. */
    fun closeCycle(cycle: QuitCycle, endMillis: Long): QuitCycle =
        if (cycle.endTimeMillis != null) cycle
        else cycle.copy(endTimeMillis = maxOf(endMillis, cycle.startTimeMillis))

    /** Length of a cycle: start to end if completed, otherwise start to [now]. */
    fun cycleDurationMillis(cycle: QuitCycle, now: Long): Long =
        elapsedMillis(cycle.startTimeMillis, cycle.endTimeMillis ?: now)

    fun elapsedMillis(startMillis: Long, nowMillis: Long): Long =
        (nowMillis - startMillis).coerceAtLeast(0L)
}
