package com.smokefree.app.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * One row per quit cycle. endTimeMillis is null while the cycle is still running.
 * Rows are never deleted: this table is the permanent cycle history.
 */
@Entity(
    tableName = "quit_cycle_history",
    indices = [Index(value = ["cycleNumber"], unique = true)]
)
data class QuitCycle(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cycleNumber: Int,
    val startTimeMillis: Long,
    val endTimeMillis: Long? = null
) {
    val isCompleted: Boolean get() = endTimeMillis != null
}
