package com.smokefree.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.smokefree.app.ui.SmokeFreeApp
import com.smokefree.app.ui.SmokeFreeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SmokeFreeTheme { SmokeFreeApp() }
        }
    }
}
