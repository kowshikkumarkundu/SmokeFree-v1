package com.smokefree.app.database

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

object Migrations {
    /**
     * v1 -> v2: adds quit_cycle_history and back-fills it from existing data.
     * Nothing in session or smoke_events is touched or deleted.
     *
     * Back-fill rules (v1 never stored cycle times, so older cycles are reconstructed):
     *  - a finished cycle ended at the time of its last smoking event (its 5th attempt);
     *  - it started when the previous cycle ended; cycle 1 started at an unknown time,
     *    so its first smoking event is used as the closest known value;
     *  - the currently active cycle keeps its exact saved start time and has no end.
     */
    val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `quit_cycle_history` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                    "`cycleNumber` INTEGER NOT NULL, " +
                    "`startTimeMillis` INTEGER NOT NULL, " +
                    "`endTimeMillis` INTEGER)"
            )
            db.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS `index_quit_cycle_history_cycleNumber` " +
                    "ON `quit_cycle_history` (`cycleNumber`)"
            )
            db.execSQL(
                "INSERT INTO quit_cycle_history (cycleNumber, startTimeMillis, endTimeMillis) " +
                    "SELECT e.cycleNumber, " +
                    "COALESCE((SELECT MAX(p.timestampMillis) FROM smoke_events p " +
                    "WHERE p.cycleNumber = e.cycleNumber - 1), MIN(e.timestampMillis)), " +
                    "MAX(e.timestampMillis) " +
                    "FROM smoke_events e " +
                    "WHERE e.cycleNumber < (SELECT cycleNumber FROM session WHERE id = 1) " +
                    "GROUP BY e.cycleNumber"
            )
            db.execSQL(
                "INSERT INTO quit_cycle_history (cycleNumber, startTimeMillis, endTimeMillis) " +
                    "SELECT cycleNumber, startTimeMillis, NULL FROM session " +
                    "WHERE id = 1 AND active = 1"
            )
        }
    }
    /** v2 -> v3: adds a reason note to each smoking event without changing old history. */
    val MIGRATION_2_3 = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE `smoke_events` ADD COLUMN `reason` TEXT NOT NULL DEFAULT ''")
        }
    }
}
