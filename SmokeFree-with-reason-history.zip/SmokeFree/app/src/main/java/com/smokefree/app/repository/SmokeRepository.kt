package com.smokefree.app.repository

import androidx.room.withTransaction
import com.smokefree.app.database.AppDatabase
import com.smokefree.app.model.QuitCycle
import com.smokefree.app.model.SessionState
import com.smokefree.app.model.SmokeEvent
import com.smokefree.app.utils.QuitLogic
import kotlinx.coroutines.flow.Flow

class SmokeRepository(private val db: AppDatabase) {
    private val sessionDao = db.sessionDao()
    private val eventDao = db.smokeEventDao()
    private val cycleDao = db.quitCycleDao()

    val session: Flow<SessionState?> = sessionDao.observe()
    val events: Flow<List<SmokeEvent>> = eventDao.observeAll()
    val cycles: Flow<List<QuitCycle>> = cycleDao.observeAll()

    /** Starts the first cycle: session row and cycle row are written in ONE transaction. */
    suspend fun startQuit(now: Long = System.currentTimeMillis()) {
        db.withTransaction {
            val current = sessionDao.get()
            val next = QuitLogic.startSession(current, now)
            if (next != current) {
                sessionDao.upsert(next)
                cycleDao.upsert(QuitLogic.openCycle(next))
            }
        }
    }

    /**
     * Records the event; on the 5th attempt also closes the current cycle and opens the next.
     * Event + cycle history + session are all written in ONE transaction (all or nothing).
     */
    suspend fun recordSmoke(now: Long = System.currentTimeMillis(), reason: String = ""): Boolean =
        db.withTransaction {
            val state = sessionDao.get()
            val result = QuitLogic.recordSmoke(state, now, reason) ?: return@withTransaction false
            eventDao.insert(result.event)
            if (result.cycleReset) {
                checkNotNull(state)
                val open = cycleDao.getByNumber(state.cycleNumber) ?: QuitLogic.openCycle(state)
                cycleDao.upsert(QuitLogic.closeCycle(open, now))
                cycleDao.upsert(QuitLogic.openCycle(result.newState))
            }
            sessionDao.upsert(result.newState)
            true
        }
}
