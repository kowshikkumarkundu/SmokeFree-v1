package com.smokefree.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smokefree.app.data.UiState
import com.smokefree.app.model.QuitCycle
import com.smokefree.app.model.SmokeEvent
import com.smokefree.app.utils.Formatters
import com.smokefree.app.utils.QuitLogic

@Composable
fun HistoryScreen(state: UiState, now: Long, onBack: () -> Unit) {
    val session = state.session
    val active = session != null && session.active
    // Events arrive newest-first, so each group is newest-first too.
    val eventsByCycle = remember(state.events) { state.events.groupBy { it.cycleNumber } }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("Back") }
            Text("History", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                LabeledRow("Total smoking events", state.events.size.toString(), bold = true)
                LabeledRow("Total quit cycles", (session?.cycleNumber ?: 0).toString(), bold = true)
                LabeledRow("Current quit cycle", if (active) session!!.cycleNumber.toString() else "-", bold = true)
                LabeledRow("Remaining attempts", if (active) session!!.attemptsRemaining.toString() else "-", bold = true)
            }
        }
        Spacer(Modifier.height(12.dp))
        if (state.cycles.isEmpty()) {
            Text("No quit cycles yet.", style = MaterialTheme.typography.bodyLarge)
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(state.cycles, key = { it.id }) { cycle ->
                    CycleCard(cycle, eventsByCycle[cycle.cycleNumber].orEmpty(), now)
                }
            }
        }
    }
}

@Composable
private fun CycleCard(cycle: QuitCycle, events: List<SmokeEvent>, now: Long) {
    Card(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Cycle ${cycle.cycleNumber}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (cycle.isCompleted) "Completed" else "In progress",
                    color = if (cycle.isCompleted) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
            LabeledRow("Started", Formatters.dateTime(cycle.startTimeMillis))
            LabeledRow("Ended", cycle.endTimeMillis?.let { Formatters.dateTime(it) } ?: "In progress")
            LabeledRow("Duration", Formatters.duration(QuitLogic.cycleDurationMillis(cycle, now)))
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            if (events.isEmpty()) {
                Text("No smoking events", style = MaterialTheme.typography.bodyMedium)
            } else {
                events.forEach { e ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        LabeledRow("Attempt ${e.attemptNumber}", Formatters.dateTime(e.timestampMillis))
                        Text(
                            "Reason: ${e.reason.ifBlank { "Not provided" }}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LabeledRow(label: String, value: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(end = 12.dp))
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
        )
    }
}
