package com.smokefree.app.utils

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

object Formatters {
    private val dateFormat = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)
    private val timeFormat = DateTimeFormatter.ofLocalizedTime(FormatStyle.MEDIUM)

    fun date(millis: Long): String =
        dateFormat.format(Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()))

    fun time(millis: Long): String =
        timeFormat.format(Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()))

    fun dateTime(millis: Long): String = "${date(millis)}  ${time(millis)}"

    /** e.g. "2d 03h 04m 05s" */
    fun duration(millis: Long): String {
        val e = ElapsedTime.fromMillis(millis)
        return String.format(Locale.US, "%dd %02dh %02dm %02ds", e.days, e.hours, e.minutes, e.seconds)
    }
}
