package com.smokefree.app.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.smokefree.app.model.QuitCycle
import com.smokefree.app.model.SessionState
import com.smokefree.app.model.SmokeEvent

@Database(
    entities = [SessionState::class, SmokeEvent::class, QuitCycle::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun sessionDao(): SessionDao
    abstract fun smokeEventDao(): SmokeEventDao
    abstract fun quitCycleDao(): QuitCycleDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "smoke_free.db"
                )
                    // No destructive fallback: user data must never be dropped.
                    .addMigrations(Migrations.MIGRATION_1_2, Migrations.MIGRATION_2_3)
                    .build().also { instance = it }
            }
    }
}
