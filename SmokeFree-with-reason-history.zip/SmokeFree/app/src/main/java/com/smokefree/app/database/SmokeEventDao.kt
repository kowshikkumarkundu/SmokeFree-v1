package com.smokefree.app.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.smokefree.app.model.SmokeEvent
import kotlinx.coroutines.flow.Flow

@Dao
interface SmokeEventDao {
    @Insert
    suspend fun insert(event: SmokeEvent): Long

    @Query("SELECT * FROM smoke_events ORDER BY timestampMillis DESC, id DESC")
    fun observeAll(): Flow<List<SmokeEvent>>
}
