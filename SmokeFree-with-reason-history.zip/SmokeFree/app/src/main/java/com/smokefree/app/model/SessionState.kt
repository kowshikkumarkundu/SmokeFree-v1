package com.smokefree.app.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/** The single source of truth for the current quit session (always row id = 1). */
@Entity(tableName = "session")
data class SessionState(
    @PrimaryKey val id: Int = 1,
    val active: Boolean,
    val startTimeMillis: Long,
    val cycleNumber: Int,
    val attemptsRemaining: Int
)
