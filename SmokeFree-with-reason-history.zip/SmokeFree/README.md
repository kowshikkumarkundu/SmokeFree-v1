# Smoke Free – offline Android app

Native Kotlin, Jetpack Compose, Material 3, Room, Coroutines/Flow, MVVM.
No permissions, no INTERNET, backups disabled, no SDKs that transmit data.

## Build the debug APK (Android Studio, beginner steps)
1. Install Android Studio (latest stable) from https://developer.android.com/studio
2. Unzip SmokeFree.zip. In Android Studio: File > Open, choose the SmokeFree folder.
3. Wait for "Gradle sync" to finish (first time downloads dependencies; needs internet for the BUILD only).
   If asked to install an Android SDK platform (API 34), click the install link.
4. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Click "locate" in the popup. File: app/build/outputs/apk/debug/app-debug.apk
   (Terminal alternative: ./gradlew assembleDebug  — on Windows: gradlew.bat assembleDebug)

## Install on your phone
1. Copy app-debug.apk to the phone (USB cable, or any file transfer).
2. On the phone open the file; if prompted, allow "Install unknown apps" for your file manager/browser.
3. Tap Install, then Open.
(Or: enable Developer options > USB debugging, plug in the phone, press the green Run button in Android Studio.)

## Run the tests
- Unit tests (logic): ./gradlew testDebugUnitTest
- Device tests (Room, persistence): connect phone/emulator, then ./gradlew connectedDebugAndroidTest

## Signed release APK
1. Build > Generate Signed App Bundle / APK > choose APK > Next.
2. Create new keystore: pick a path, set passwords, alias, validity 25+ years. KEEP THIS FILE AND PASSWORDS SAFE (needed for all future updates).
3. Next > select "release" > check V1 and V2 signature > Finish.
4. Output: app/release/app-release.apk. Install it like the debug APK.
Command line alternative: create keystore with
  keytool -genkey -v -keystore smokefree.jks -keyalg RSA -keysize 2048 -validity 10000 -alias smokefree
then sign with apksigner after building an unsigned release (the Android Studio wizard is simpler).

## Notes
- Timer = saved start timestamp vs. current system clock; survives restart, no service.
- The 5th "I Smoked" press stores the event and starts the next cycle automatically in one DB transaction.
- Rapid taps within 0.8 s are ignored to prevent duplicate events.

## Version 1.1 changes
- New Room table `quit_cycle_history` (cycle number, start, end). Database version 2 with `Migrations.MIGRATION_1_2`.
- Installing v1.1 over v1.0 keeps all data; older cycles are back-filled (cycle 1's start is approximated by its first smoking event).
- History screen shows each cycle with start, end, duration and its smoking events.
- Tests: `./gradlew testDebugUnitTest` (CycleLogicTest, QuitLogicTest); on device: `./gradlew connectedDebugAndroidTest` (CycleRepositoryTest, MigrationTest).
